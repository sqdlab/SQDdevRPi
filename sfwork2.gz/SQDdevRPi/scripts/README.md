**NOTE: These SSH scripts are obsolete, but can be used for quick debugging via some SSH console.**

The scheme uses Python scripts that run on the Raspberry Pi. There is a **console interface** that one may access via **SSH**. *SQDToolz* uses this interface to communicate with the Raspberry Pi via the `paramiko` library. To use the library, consult the documentation:

- [Setting up the Raspberry Pi](docs/Setting_up_the_RPi.md)
- Available scripts:
    - GPIO interface
    - Windfreak serial interface
